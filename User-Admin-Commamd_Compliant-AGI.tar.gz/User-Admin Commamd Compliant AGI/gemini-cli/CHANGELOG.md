# Changelog

Changelogs for each release are located on the [releases page](https://github.com/google-github-actions/run-gemini-cli/releases).
