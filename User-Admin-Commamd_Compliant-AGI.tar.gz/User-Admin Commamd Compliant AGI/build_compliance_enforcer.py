#!/usr/bin/env python3
"""
Universal Build Compliance Enforcer Script
=========================================

Purpose:
- Provides a unified, agentic enforcement pipeline for build compliance across all repositories and build systems.
- Adapts dynamically to per-repo/per-build standards (CI/CD, code hygiene, artifact checks, Android compatibility, etc.).
- Modular, reproducible, and versioned: Each enforcement run is logged and version-tracked.

Features:
- Command parsing (intent detection) for build, lint, test, artifact, and hygiene enforcement.
- Sandboxed execution (safe subprocess, no direct sys.exit).
- Artifact and hygiene checks: file normalization, empty removal, Android compatibility verification.
- Audit log (JSON, file-based), version trace.
- Extensible: Add repo/build-specific compliance rules via intent parsing.

Usage:
    python build_compliance_enforcer.py "Run full compliance for Android build"
    python build_compliance_enforcer.py "Check hygiene and lint for repo"
    Or interactive mode.

Dependencies:
- Python 3 built-ins: os, shutil, subprocess, re, logging, json, sys, argparse, datetime
- No external libraries required.

References:
- Foundational standards vault: /reference
- Agentic enforcement: AGIEnforcer v1-v3 (see prompt)
- Android build compliance: https://developer.android.com/studio/build
- CI/CD trends: https://docs.github.com/en/actions
- File hygiene: ebc09_fs-utils_paper (see vault)
"""

import os
import shutil
import subprocess
import re
import logging
import sys
import argparse
from datetime import datetime
import json

# Logging setup (JSON versioned audit)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.FileHandler(f'compliance_log_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'), logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

class ComplianceEnforcer:
    def __init__(self, sandbox_dir='compliance_sandbox'):
        self.sandbox_dir = os.path.abspath(sandbox_dir)
        os.makedirs(self.sandbox_dir, exist_ok=True)
        self.run_id = datetime.now().isoformat()
        self.audit_file = os.path.join(self.sandbox_dir, 'compliance_audit.json')
        self.audit_log = self._load_audit()
        logger.info(f"Compliance Enforcer initialized in {self.sandbox_dir}, Run ID: {self.run_id}")

    def _load_audit(self):
        if os.path.exists(self.audit_file):
            with open(self.audit_file, 'r') as f:
                return json.load(f)
        return {}

    def _save_audit(self):
        with open(self.audit_file, 'w') as f:
            json.dump(self.audit_log, f, indent=2)

    # Hygiene enforcement: normalize names, remove empties
    def _file_hygiene(self, path):
        for root, dirs, files in os.walk(path):
            for dir in dirs[:]:
                dir_path = os.path.join(root, dir)
                if not os.listdir(dir_path):
                    os.rmdir(dir_path)
                    logger.info(f"Hygiene: Removed empty dir {dir_path}")
            for file in files:
                # Normalize to snake_case and lower
                if ' ' in file or not re.match(r'^[a-z_0-9]+\.(txt|py|json|java|kt|xml|gradle)$', file.lower()):
                    old_path = os.path.join(root, file)
                    new_name = re.sub(r'\s+', '_', file).lower().replace('-', '_')
                    new_path = os.path.join(root, new_name)
                    shutil.move(old_path, new_path)
                    logger.info(f"Hygiene: Normalized {file} -> {new_name}")

    # Build intent parser: detects build/lint/test/artifact/hygiene commands
    def parse_intent(self, command: str) -> dict:
        command_lower = command.lower()
        intent = 'unknown'
        params = {}

        # Hygiene
        if re.search(r'\b(hygiene|normalize|clean)\b', command_lower):
            intent = 'hygiene'
            params['path'] = re.search(r'(dir|path|repo)\s+(\S+)', command_lower)
            params['path'] = params['path'].group(2) if params['path'] else self.sandbox_dir

        # Build (Android, general)
        elif re.search(r'\b(build|compile|assemble)\b', command_lower):
            intent = 'build'
            params['target'] = re.search(r'(android|gradle|make|cmake|node|npm|yarn)', command_lower)
            params['target'] = params['target'].group(0) if params['target'] else 'default'

        # Lint
        elif re.search(r'\b(lint|checkstyle|pylint|eslint)\b', command_lower):
            intent = 'lint'
            params['tool'] = re.search(r'(checkstyle|pylint|eslint|ktlint)', command_lower)
            params['tool'] = params['tool'].group(0) if params['tool'] else 'generic'

        # Test
        elif re.search(r'\b(test|unittest|pytest|junit)\b', command_lower):
            intent = 'test'
            params['framework'] = re.search(r'(pytest|junit|unittest)', command_lower)
            params['framework'] = params['framework'].group(0) if params['framework'] else 'generic'

        # Artifact
        elif re.search(r'\b(artifact|output|apk|jar|war)\b', command_lower):
            intent = 'artifact_check'
            params['type'] = re.search(r'(apk|jar|war|exe)', command_lower)
            params['type'] = params['type'].group(0) if params['type'] else 'generic'

        # Android compatibility
        elif re.search(r'\bandroid\b', command_lower):
            intent = 'android_check'
            params['min_sdk'] = re.search(r'android\s+sdk\s*(\d+)', command_lower)
            params['min_sdk'] = int(params['min_sdk'].group(1)) if params['min_sdk'] else 21  # Android 5.0

        logger.info(f"Parsed intent: {intent}, params: {params}")
        return {'intent': intent, 'params': params}

    # Modular enforcement logic
    def enforce(self, intent_dict: dict) -> str:
        intent = intent_dict['intent']
        params = intent_dict['params']
        result = ""

        try:
            if intent == 'hygiene':
                self._file_hygiene(params['path'])
                result = f"Hygiene enforced on {params['path']}: Empties removed, names normalized."
            elif intent == 'build':
                # Sandbox: run build tool
                build_cmd = []
                if params['target'] == 'android':
                    build_cmd = ['./gradlew', 'assembleDebug']
                elif params['target'] == 'gradle':
                    build_cmd = ['gradle', 'build']
                elif params['target'] == 'make':
                    build_cmd = ['make']
                elif params['target'] == 'npm':
                    build_cmd = ['npm', 'run', 'build']
                else:
                    build_cmd = ['echo', 'No build system detected.']
                proc = subprocess.run(build_cmd, cwd=self.sandbox_dir, capture_output=True, text=True)
                result = f"Build output: {proc.stdout}\nErrors: {proc.stderr}"
            elif intent == 'lint':
                lint_cmd = []
                if params['tool'] == 'checkstyle':
                    lint_cmd = ['checkstyle']
                elif params['tool'] == 'pylint':
                    lint_cmd = ['pylint', '.']
                elif params['tool'] == 'eslint':
                    lint_cmd = ['eslint', '.']
                elif params['tool'] == 'ktlint':
                    lint_cmd = ['ktlint']
                else:
                    lint_cmd = ['echo', 'Generic lint check']
                proc = subprocess.run(lint_cmd, cwd=self.sandbox_dir, capture_output=True, text=True)
                result = f"Lint output: {proc.stdout}\nErrors: {proc.stderr}"
            elif intent == 'test':
                test_cmd = []
                if params['framework'] == 'pytest':
                    test_cmd = ['pytest']
                elif params['framework'] == 'junit':
                    test_cmd = ['junit']
                elif params['framework'] == 'unittest':
                    test_cmd = ['python', '-m', 'unittest', 'discover']
                else:
                    test_cmd = ['echo', 'Generic test framework']
                proc = subprocess.run(test_cmd, cwd=self.sandbox_dir, capture_output=True, text=True)
                result = f"Test output: {proc.stdout}\nErrors: {proc.stderr}"
            elif intent == 'artifact_check':
                found = []
                for root, _, files in os.walk(self.sandbox_dir):
                    for file in files:
                        if params['type'] in file.lower():
                            found.append(os.path.join(root, file))
                result = f"Artifacts found: {found if found else 'None'}"
            elif intent == 'android_check':
                # Android compatibility stub (real: parse build.gradle)
                gradle_file = os.path.join(self.sandbox_dir, 'build.gradle')
                min_sdk = params['min_sdk']
                android_ok = False
                if os.path.exists(gradle_file):
                    with open(gradle_file) as f:
                        content = f.read()
                        match = re.search(r'minSdkVersion\s+(\d+)', content)
                        if match and int(match.group(1)) >= min_sdk:
                            android_ok = True
                result = f"Android SDK compatibility: {'PASS' if android_ok else 'FAIL'} for minSdk {min_sdk}"
            else:
                result = f"Unsupported intent: {intent}. Try build, lint, test, artifact, hygiene, or android_check."
            
            # Audit log
            self.audit_log[self.run_id] = {'intent': intent, 'result': result, 'timestamp': datetime.now().isoformat()}
            self._save_audit()

            logger.info(f"Enforced {intent}: {result}")
            return result

        except Exception as e:
            error_msg = f"Enforcement failed for {intent}: {str(e)}"
            logger.error(error_msg)
            return error_msg

    def run(self, command: str) -> str:
        intent_dict = self.parse_intent(command)
        logger.info(f"Planning enforcement: {intent_dict}")
        result = self.enforce(intent_dict)
        logger.info(f"Verification: {result}")
        return result

def main():
    parser = argparse.ArgumentParser(description="Universal Build Compliance Enforcer")
    parser.add_argument('command', nargs='?', help="Natural language compliance command")
    args = parser.parse_args()

    enforcer = ComplianceEnforcer()

    if args.command:
        print(enforcer.run(args.command))
    else:
        print("Compliance Enforcer ready. Enter commands (or 'quit' to exit):")
        while True:
            user_input = input("> ").strip()
            if user_input.lower() == 'quit':
                break
            if user_input:
                print(enforcer.run(user_input))

if __name__ == "__main__":
    main()

# References
# - Foundational standards: /reference
# - Android build compliance: https://developer.android.com/studio/build
# - CI/CD: https://docs.github.com/en/actions
# - File hygiene: ebc09_fs-utils_paper (see /reference vault)